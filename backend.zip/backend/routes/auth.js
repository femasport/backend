const router = require('express').Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ where: { email } });
  if (!user) return res.status(400).json({ message: 'Usuario no encontrado' });
  const valid = bcrypt.compareSync(password, user.password);
  if (!valid) return res.status(400).json({ message: 'Contraseña incorrecta' });
  const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET);
  res.json({ token });
});

router.post('/admin', async (req, res) => {
  const { email, password, nombre } = req.body;
  const hash = bcrypt.hashSync(password, 8);
  const user = await User.create({ email, password: hash, nombre });
  res.json(user);
});

module.exports = router;
