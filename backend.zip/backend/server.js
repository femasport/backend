const express = require('express');
const cors = require('cors');
const sequelize = require('./config/db');
const authRoutes = require('./routes/auth');
const courseRoutes = require('./routes/courses');
const User = require('./models/User');
const Course = require('./models/Course');

require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/auth', authRoutes);
app.use('/courses', courseRoutes);

app.get('/stats', async (req, res) => {
  const courses = await Course.count();
  const admins = await User.count();
  res.json({ courses, admins });
});

sequelize.sync().then(() => {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log('Server running on port', PORT));
});
